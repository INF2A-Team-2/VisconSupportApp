export enum AccountType {
    User,
    HelpDesk,
    Admin
}

export interface User {
    id: number;
    username: string;
    type: AccountType;
    phoneNumber: string;
    unit: string;
    companyId: number;
}

export interface Company {
    id: number;
    name: string;
}

export type Machine = {
    id: number;
    name: string;
}

export type Issue = {
    id : number;
    headline : string;
    actual : string;
    expected: string;
    tried: string;
    timeStamp: string;
    userId: number;
    machineId: number;
}

export type Message = {
    id: number;
    name: string;
    body: string;
    timeStamp: string;
    userId: number;
    issueId: number;
}

export type Attachment = {
    id: number,
    name?: string,
    mimeType: string,
    issueId: number,
    url?: string
}

export type Media = {
    name?: string,
    data?: ArrayBuffer,
    mimeType: string
};

export enum FieldType {
    Text,
    Password,
    Number,
    Selection
}

export type Field = {
    name: string,
    key: string,
    type: FieldType,
    required: boolean,
    options?: Array<{
        value: string,
        label: string
    }>,
    isNumber?: boolean
}
